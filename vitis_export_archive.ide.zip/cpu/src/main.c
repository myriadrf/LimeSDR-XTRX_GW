/*
 * main.c
 */

#include <stdio.h>
#include <stdbool.h>
#include "platform.h"
#include "xil_printf.h"
#include <xgpio.h> 		/* GPIO driver*/
#include <xiic.h>		/* I2C driver*/
#include "xspi.h"		/* SPI device driver */
#include "AXI_to_native_FIFO.h" /* Native FIFO driver*/

#include "fpga_flash_qspi.h"
#include "LMS64C_protocol.h"
#include "PCIe_5GRadio_brd.h"
#include "pll_rcfg.h"
#include "ads4246_reg.h"
#include "sleep.h"
#include "utility_functions.h"

/************************** Constant Definitions *****************************/
/*
 * The following constants map to the XPAR parameters created in the
 * xparameters.h file. They are defined here such that a user can easily
 * change all the needed parameters in one place.
 */
#define SPI0_DEVICE_ID			XPAR_SPI_0_DEVICE_ID
#define QSPI_DEVICE_ID			XPAR_SPI_CORES_SPI1_FLASH_DEVICE_ID

/*
 * The following constant defines the slave select signal that is used to
 * to select the  device on the SPI bus, this signal is typically
 * connected to the chip select of the device.
 */
#define SPI0_FPGA_SS		0x01
#define SPI0_LMS7002M_1_SS	0x02

#define BRD_SPI_REG_LMS1_LMS2_CTRL  0x13
#define LMS1_SS			0
#define LMS1_RESET		1
#define MEMORY_MAP_REG_MSB 0xFF
#define MEMORY_MAP_REG_LSB 0xFF
#define MEMOR_MAP_BIT 0x0
//LEGACY DEFINES
//#define LMS2_SS			8
//#define LMS2_RESET		9

/*
* The following constants are part of clock dynamic reconfiguration
* They are only defined here such that a user can easily change
* needed parameters
*/

#define CLK_LOCK			1

/*FIXED Value */
#define VCO_FREQ			600
#define CLK_WIZ_VCO_FACTOR		(VCO_FREQ * 10000)

 /*Input frequency in MHz */
#define DYNAMIC_INPUT_FREQ		100
#define DYNAMIC_INPUT_FREQ_FACTOR	(DYNAMIC_INPUT_FREQ * 10000)

/*
 * Output frequency in MHz. User need to change this value to
 * generate grater/lesser interrupt as per input frequency
 */
#define DYNAMIC_OUTPUT_FREQ		25
#define DYNAMIC_OUTPUT_FREQFACTOR	(DYNAMIC_OUTPUT_FREQ * 10000)

#define CLK_WIZ_RECONFIG_OUTPUT		DYNAMIC_OUTPUT_FREQ
#define CLK_FRAC_EN			1

uint8_t temp_buffer0[4];
uint8_t temp_buffer1[4];
// storage for dac values
uint16_t pa1_dac_val = 0xFFFF;
uint16_t pa2_dac_val = 0xFFFF;
uint16_t dac_val = 30714;		//TCXO DAC value
signed short int converted_val = 300;	//Temperature
int data_cnt=0;


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */
static XSpi Spi0, Spi1, Spi2;
static XSpi CFG_QSPI;
static XGpio gpio, pll_rst, pllcfg_cmd, pllcfg_stat, extm_0_axi_sel, smpl_cmp_sel, smpl_cmp_en, smpl_cmp_status;

static XGpio vctcxo_tamer_ctrl;
//XClk_Wiz ClkWiz_Dynamic; /* The instance of the ClkWiz_Dynamic */


#define sbi(p,n) ((p) |= (1UL << (n)))
#define cbi(p,n) ((p) &= ~(1 << (n)))

#define FW_VER			1 //Initial version

//Variables for QSPI config (configuration flash programming)
unsigned long int last_portion, current_portion, fpga_data, fpga_byte;
//unsigned char data_cnt, sc_brdg_data[255];

uint8_t test, block, cmd_errors, glEp0Buffer_Rx[64], glEp0Buffer_Tx[64];
tLMS_Ctrl_Packet *LMS_Ctrl_Packet_Tx = (tLMS_Ctrl_Packet*)glEp0Buffer_Tx;
tLMS_Ctrl_Packet *LMS_Ctrl_Packet_Rx = (tLMS_Ctrl_Packet*)glEp0Buffer_Rx;

/**	This function checks if all blocks could fit in data field.
*	If blocks will not fit, function returns TRUE. */
unsigned char Check_many_blocks (unsigned char block_size)
{
	if (LMS_Ctrl_Packet_Rx->Header.Data_blocks > (sizeof(LMS_Ctrl_Packet_Tx->Data_field)/block_size))
	{
		LMS_Ctrl_Packet_Tx->Header.Status = STATUS_BLOCKS_ERROR_CMD;
		return 1;
	}
	else return 0;
	return 1;
}



void Init_SPI(u16 DeviceId, XSpi *InstancePtr, u32 Options)
{
	int spi_status;
	XSpi_Config *ConfigPtr;

	/*
	 * Initialize the SPI driver so that it is  ready to use.
	 */
	ConfigPtr = XSpi_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		//return XST_DEVICE_NOT_FOUND;
	}
	//ATTENTION DIRTY OVERRIDE FOR SPI2. VITIS DOESNT SEEM TO
	//CORRECTLY IMPORT SPI2 NUMBER OF SLAVES FROM HW DEFINITION
	//TODO: FIGURE OUT WHY. FOR NOW THIS WORKS FINE
//	if (DeviceId == 0x02)
//			ConfigPtr->NumSlaveBits = 4;

	spi_status = XSpi_CfgInitialize(InstancePtr, ConfigPtr,
				  ConfigPtr->BaseAddress);
	if (spi_status != XST_SUCCESS) {
		//return XST_FAILURE;
	}

	/*
	 * Set the SPI device as a master and in manual slave select mode such
	 * that the slave select signal does not toggle for every byte of a
	 * transfer, this must be done before the slave select is set.
	 */
	spi_status = XSpi_SetOptions(InstancePtr, Options);
	if(spi_status != XST_SUCCESS) {
		//return XST_FAILURE;
	}

	// Start the SPI driver so that interrupts and the device are enabled
	spi_status = XSpi_Start(InstancePtr);

	//disable global interrupts since we will use a polled approach
	XSpi_IntrGlobalDisable(InstancePtr);


}

/** Cchecks if peripheral ID is valid.
 Returns 1 if valid, else 0. */
unsigned char Check_Periph_ID (unsigned char max_periph_id, unsigned char Periph_ID)
{
		if (LMS_Ctrl_Packet_Rx->Header.Periph_ID > max_periph_id)
		{
		LMS_Ctrl_Packet_Tx->Header.Status = STATUS_INVALID_PERIPH_ID_CMD;
		return 0;
		}
	else return 1;
}

/**
 * Gets 64 bytes packet from FIFO.
 */
void getFifoData(uint8_t *buf, uint8_t k)
{
	uint8_t cnt = 0;
	uint32_t* dest = (uint32_t*)buf;
	for(cnt=0; cnt<k/sizeof(uint32_t); ++cnt)
	{
		dest[cnt] = AXI_TO_NATIVE_FIFO_mReadReg(XPAR_AXI_TO_NATIVE_FIFO_0_S00_AXI_BASEADDR, AXI_TO_NATIVE_FIFO_S00_AXI_SLV_REG1_OFFSET);
	};
}


/**
 *	@brief Function to modify BRD (FPGA) spi register bits
 *	@param SPI_reg_addr register address
 *	@param MSB_bit MSB bit of range that will be modified
 *	@param LSB_bit LSB bit of range that will be modified
 */
void Modify_BRDSPI16_Reg_bits (unsigned short int SPI_reg_addr, unsigned char MSB_bit, unsigned char LSB_bit, unsigned short int new_bits_data)
{
	unsigned short int mask, SPI_reg_data;
	unsigned char bits_number;
	//uint8_t MSB_byte, LSB_byte;
	unsigned char WrBuff[4];
	unsigned char RdBuff[4];
	int spirez;

	//**Reconfigure_SPI_for_LMS();

	bits_number = MSB_bit - LSB_bit + 1;

	mask = 0xFFFF;

	//removing unnecessary bits from mask
	mask = mask << (16 - bits_number);
	mask = mask >> (16 - bits_number);

	new_bits_data &= mask; //mask new data

	new_bits_data = new_bits_data << LSB_bit; //shift new data

	mask = mask << LSB_bit; //shift mask
	mask =~ mask;//invert mask

	// Read original data
	WrBuff[0] = (SPI_reg_addr >> 8 ) & 0xFF; //MSB_byte
	WrBuff[1] = SPI_reg_addr & 0xFF; //LSB_byte
	cbi(WrBuff[0], 7);  //clear write bit
	//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, SPI_NR_FPGA, 2, WrBuff, 2, RdBuff, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, WrBuff, RdBuff, 4);

	//SPI_reg_data = (RdBuff[0] << 8) + RdBuff[1]; //read current SPI reg data
	// we are reading 4 bytes
	SPI_reg_data = (RdBuff[2] << 8) + RdBuff[3]; //read current SPI reg data

	//modify reg data
	SPI_reg_data &= mask;//clear bits
	SPI_reg_data |= new_bits_data; //set bits with new data

	//write reg addr
	WrBuff[0] = (SPI_reg_addr >> 8 ) & 0xFF; //MSB_byte
	WrBuff[1] = SPI_reg_addr & 0xFF; //LSB_byte
	//modified data to be written to SPI reg
	WrBuff[2] = (SPI_reg_data >> 8 ) & 0xFF;
	WrBuff[3] = SPI_reg_data & 0xFF;
	sbi(WrBuff[0], 7); //set write bit
	//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, SPI_NR_FPGA, 4, WrBuff, 0, NULL, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, WrBuff, NULL, 4);
}



void ResetPLL(void)
{
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	int pll_ind, spirez;

	// Read
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x23;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);

	// Get PLL index
	pll_ind = PLL_IND(rd_buf[3]); //(rd_buf[0] >> 3) & 0x3F;


	// Toggle reset line of appropriate PLL
    //IOWR(PLL_RST_BASE, 0x00, 0x01 << pll_ind);	//Set to 1
    XGpio_DiscreteWrite(&pll_rst, 1, 0x01 << pll_ind);
    asm("nop"); asm("nop");
    //IOWR(PLL_RST_BASE, 0x00, 0x00);	//Set to 0
    XGpio_DiscreteWrite(&pll_rst, 1, 0x00);

    /* PLL Software reset trough AXI interface*/
	//XGpio_DiscreteWrite(&extm_0_axi_sel, 1, pll_ind); 	// Select AXI slave
	//Xil_Out32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_RESET, 0x0000000A);	// Write to CCR
}

// Change PLL phase
void RdPLLCFG(tXPLL_CFG *pll_cfg)
{
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	uint8_t value_cap;
	int spirez;

	uint8_t D_BYP, M_BYP, C0_BYP, C1_BYP, C2_BYP, C3_BYP, C4_BYP, C5_BYP, C6_BYP;

	/* Get DIV and MULT bypass values */
	/* D_BYP and M_BYP values comes from compatibility with existing Altera GW*/
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x26;	// Command and Address
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	D_BYP = rd_buf[3] & 0x01;
	M_BYP = (rd_buf[3] >> 2) & 0x01;

	/* Get Output counter bypass values */
	/* OX_BYP values comes from compatibility with existing Altera GW*/
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x27;	// Command and Address
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	C0_BYP = rd_buf[3] & 0x01;
	C1_BYP = (rd_buf[3] >>  2) & 0x01;
	C2_BYP = (rd_buf[3] >>  4) & 0x01;
	C3_BYP = (rd_buf[3] >>  6) & 0x01;
	C4_BYP = (rd_buf[2]) & 0x01;
	C5_BYP = (rd_buf[2] >> 2) & 0x01;
	C6_BYP = (rd_buf[2] >> 4) & 0x01;

	/* Read Divide value */
	if (D_BYP) {
		pll_cfg->DIVCLK_DIVIDE =1;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x2A;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		value_cap = rd_buf[2] + rd_buf[3];
		if(value_cap > 64)
			value_cap = 64;
		pll_cfg->DIVCLK_DIVIDE	= value_cap;//rd_buf[2] + rd_buf[3];
	}

	/* Read Multiply value */
	if (M_BYP) {
		pll_cfg->CLKFBOUT_MULT	=1;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x2B;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		value_cap = rd_buf[2] + rd_buf[3];
		if(value_cap > 64)
			value_cap = 64;
		pll_cfg->CLKFBOUT_MULT	= value_cap;
//		pll_cfg->CLKFBOUT_MULT	=rd_buf[2] + rd_buf[3];
	}

	/* Read Fractional multiply part*/
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x2C;	// Command and Address
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	pll_cfg->CLKFBOUT_FRAC	=MFRAC_CNT_LSB(rd_buf[2], rd_buf[3]);

	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x2D;	// Command and Address
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);

	pll_cfg->CLKFBOUT_FRAC	= pll_cfg->CLKFBOUT_FRAC | MFRAC_CNT_MSB(rd_buf[2], rd_buf[3]);
	pll_cfg->CLKFBOUT_PHASE	=0;

	/* Read C0 divider*/
	if (C0_BYP) {
		pll_cfg->CLKOUT0_DIVIDE  = 1;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x2E;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		value_cap = rd_buf[2] + rd_buf[3];
		if(value_cap > 64)
			value_cap = 64;
		pll_cfg->CLKOUT0_DIVIDE	= value_cap;//rd_buf[2] + rd_buf[3];
	}


	pll_cfg->CLKOUT0_FRAC    =0;
	pll_cfg->CLKOUT0_PHASE   =0*1000;	//Phase value = (Phase Requested) * 1000. For example, for a 45.5 degree phase, the required value is 45500 = 0xB1BC.
	pll_cfg->CLKOUT0_DUTY    =50*1000; 	//Duty cycle value = (Duty Cycle in %) * 1000

	/* Read C1 divider*/
	if (C1_BYP) {
		pll_cfg->CLKOUT1_DIVIDE  = pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x2F;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		value_cap = rd_buf[2] + rd_buf[3];
		if(value_cap > 64)
			value_cap = 64;
		pll_cfg->CLKOUT1_DIVIDE	= value_cap;//rd_buf[2] + rd_buf[3];
	}

	/* Read phase value */
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x20;	// Command and Address
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	value_cap = rd_buf[3];

	pll_cfg->CLKOUT1_PHASE   =value_cap*1000;
	pll_cfg->CLKOUT1_DUTY    =50*1000;

	/* Read C2 divider*/
	if (C2_BYP) {
		/* All register has to be set to valid values so we take same value as CO output */
		pll_cfg->CLKOUT2_DIVIDE  = pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x30;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		pll_cfg->CLKOUT2_DIVIDE	= rd_buf[2] + rd_buf[3];
	}

	pll_cfg->CLKOUT2_PHASE   =0;
	pll_cfg->CLKOUT2_DUTY    =50*1000;

	/* Read C3 divider*/
	if (C3_BYP) {
		/* All register has to be set to valid values so we take same value as CO output */
		pll_cfg->CLKOUT3_DIVIDE  =pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x31;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		pll_cfg->CLKOUT3_DIVIDE	= rd_buf[2] + rd_buf[3];
	}

	pll_cfg->CLKOUT3_PHASE   =0;
	pll_cfg->CLKOUT3_DUTY    =50*1000;

	/* Read C4 divider*/
	if (C4_BYP) {
		/* All register has to be set to valid values so we take same value as CO output */
		pll_cfg->CLKOUT4_DIVIDE  =pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x32;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		pll_cfg->CLKOUT4_DIVIDE	= rd_buf[2] + rd_buf[3];
	}
	pll_cfg->CLKOUT4_PHASE   =0;
	pll_cfg->CLKOUT4_DUTY    =50*1000;

	/* Read C5 divider*/
	if (C5_BYP) {
		/* All register has to be set to valid values so we take same value as CO output */
		pll_cfg->CLKOUT5_DIVIDE  =pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x33;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		pll_cfg->CLKOUT5_DIVIDE	= rd_buf[2] + rd_buf[3];
	}
	pll_cfg->CLKOUT5_PHASE   =0;
	pll_cfg->CLKOUT5_DUTY    =50*1000;

	/* Read C6 divider*/
	if (C6_BYP) {
		/* All register has to be set to valid values so we take same value as CO output */
		pll_cfg->CLKOUT6_DIVIDE  =pll_cfg->CLKOUT0_DIVIDE;
	}
	else{
		wr_buf[0] = 0x00;	// Command and Address
		wr_buf[1] = 0x34;	// Command and Address
		spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
		spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
		pll_cfg->CLKOUT6_DIVIDE	= rd_buf[2] + rd_buf[3];
	}
	pll_cfg->CLKOUT6_PHASE   =0;
	pll_cfg->CLKOUT6_DUTY    =50*1000;

}

// Change PLL phase
void RdTXPLLCFG(tXPLL_CFG *pll_cfg)
{
	pll_cfg->DIVCLK_DIVIDE	=1;
	pll_cfg->CLKFBOUT_MULT	=64;
	pll_cfg->CLKFBOUT_FRAC	=0;
	pll_cfg->CLKFBOUT_PHASE	=0;

	pll_cfg->CLKOUT0_DIVIDE  =64;
	pll_cfg->CLKOUT0_FRAC    =0;
	pll_cfg->CLKOUT0_PHASE   =0*1000;	//Phase value = (Phase Requested) * 1000. For example, for a 45.5 degree phase, the required value is 45500 = 0xB1BC.
	pll_cfg->CLKOUT0_DUTY    =50*1000; 	//Duty cycle value = (Duty Cycle in %) * 1000

	pll_cfg->CLKOUT1_DIVIDE  =64;
	pll_cfg->CLKOUT1_PHASE   =90*1000;
	pll_cfg->CLKOUT1_DUTY    =50*1000;

	pll_cfg->CLKOUT2_DIVIDE  =64;
	pll_cfg->CLKOUT2_PHASE   =0;
	pll_cfg->CLKOUT2_DUTY    =50*1000;

	pll_cfg->CLKOUT3_DIVIDE  =64;
	pll_cfg->CLKOUT3_PHASE   =0;
	pll_cfg->CLKOUT3_DUTY    =50*1000;

	pll_cfg->CLKOUT4_DIVIDE  =64;
	pll_cfg->CLKOUT4_PHASE   =0;
	pll_cfg->CLKOUT4_DUTY    =50*1000;

	pll_cfg->CLKOUT5_DIVIDE  =64;
	pll_cfg->CLKOUT5_PHASE   =0;
	pll_cfg->CLKOUT5_DUTY    =50*1000;

	pll_cfg->CLKOUT6_DIVIDE  =64;
	pll_cfg->CLKOUT6_PHASE   =0;
	pll_cfg->CLKOUT6_DUTY    =50*1000;

}

void RdADCPLLCFG(tXPLL_CFG *pll_cfg)
{
	pll_cfg->DIVCLK_DIVIDE	=1;
	pll_cfg->CLKFBOUT_MULT	=46;
	pll_cfg->CLKFBOUT_FRAC	=0;
	pll_cfg->CLKFBOUT_PHASE	=0;

	pll_cfg->CLKOUT0_DIVIDE  =46;
	pll_cfg->CLKOUT0_FRAC    =0;
	pll_cfg->CLKOUT0_PHASE   =-10*1000;	//Phase value = (Phase Requested) * 1000. For example, for a 45.5 degree phase, the required value is 45500 = 0xB1BC.
	pll_cfg->CLKOUT0_DUTY    =50*1000; 	//Duty cycle value = (Duty Cycle in %) * 1000

	pll_cfg->CLKOUT1_DIVIDE  =46;
	pll_cfg->CLKOUT1_PHASE   =360*1000;
	pll_cfg->CLKOUT1_DUTY    =50*1000;

	pll_cfg->CLKOUT2_DIVIDE  =46;
	pll_cfg->CLKOUT2_PHASE   =0;
	pll_cfg->CLKOUT2_DUTY    =50*1000;

	pll_cfg->CLKOUT3_DIVIDE  =46;
	pll_cfg->CLKOUT3_PHASE   =0;
	pll_cfg->CLKOUT3_DUTY    =50*1000;

	pll_cfg->CLKOUT4_DIVIDE  =46;
	pll_cfg->CLKOUT4_PHASE   =0;
	pll_cfg->CLKOUT4_DUTY    =50*1000;

	pll_cfg->CLKOUT5_DIVIDE  =46;
	pll_cfg->CLKOUT5_PHASE   =0;
	pll_cfg->CLKOUT5_DUTY    =50*1000;

	pll_cfg->CLKOUT6_DIVIDE  =46;
	pll_cfg->CLKOUT6_PHASE   =0;
	pll_cfg->CLKOUT6_DUTY    =50*1000;

}




// Change PLL phase
uint8_t UpdatePHCFG(void)
{
	uint32_t PLL_BASE;
	uint32_t Val, Cx, Dir;
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	int pll_ind, spirez;
	uint8_t pllcfgrez;
	tXPLL_CFG pll_cfg = {0};

	// Read
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x23;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);

	// Get PLL base address
	//PLL_BASE = GetPLLCFG_Base( PLL_IND(rd_buf[1]) );

	// Get PLL index
	pll_ind = PLL_IND(rd_buf[3]); //(rd_buf[0] >> 3) & 0x3F;

    /* PLL Software reset trough AXI interface*/
	XGpio_DiscreteWrite(&extm_0_axi_sel, 1, 1); 					// Select PLL AXI slave
	Xil_Out32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_RESET, 0x0000000A);	// Write 0x0000000A value to reset PLL

	//Write in Mode Register "0" for waitrequest mode, "1" for polling mode
	//IOWR_32DIRECT(PLL_BASE, MODE, 0x01);

	// Set Up/Down
	Dir = PH_DIR(rd_buf[0]); //(rd_buf[1] >> 5) & 0x01;

	// Set Cx
	Cx = CX_IND(rd_buf[0]) - 2; //(rd_buf[1] & 0x1F);

	// Set Phase Cnt
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x24;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	Val = CX_PHASE(rd_buf[0], rd_buf[1]); //(rd_buf[1] << 8) | rd_buf[0];

	// Set Phase shift register
	//set_Phase(PLL_BASE, Cx, Val, Dir);
	// Apply PLL configuration
	//pllcfgrez = start_Reconfig(PLL_BASE);

	switch(pll_ind) {
	case 0:
		RdRXPLLCFG(&pll_cfg);
		break;
	case 1:
		RdRXPLLCFG(&pll_cfg);
		break;
	case 2:
		RdRXPLLCFG(&pll_cfg);
		break;
	case 3:
		RdRXPLLCFG(&pll_cfg);
		break;
	default:
		RdRXPLLCFG(&pll_cfg);
		break;
	}




	// Update PLL configuration;
	pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);

	// Apply PLL configuration
	pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);

	Xil_Out32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_RESET, 0x0000000A);	// Write 0x0000000A value to reset PLL

	for (int i=0; i<3600; i++){
		pll_cfg.CLKOUT1_PHASE = i*100;
		pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
		pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);
	}



	return pllcfgrez;
}

int CheckSamples(int sel) {

	int cmp_status = 1;
	int timeout;

	/* Select sample compare MUX */
	XGpio_DiscreteWrite(&smpl_cmp_sel, 1, sel);
	/* Disable sample compare*/
	XGpio_DiscreteWrite(&smpl_cmp_en, 1, 0x00);


	timeout = 0;
	do {
		cmp_status = XGpio_DiscreteRead(&smpl_cmp_status, 1);
		if (timeout++ > PLLCFG_TIMEOUT) return 0;
	}
	while((cmp_status & 0x01)!= 0);

	/* Enalbe sample compare */
	XGpio_DiscreteWrite(&smpl_cmp_en, 1, 0x01);

	timeout = 0;
	do {
		cmp_status = XGpio_DiscreteRead(&smpl_cmp_status, 1);
		if (timeout++ > PLLCFG_TIMEOUT) return 0;
	}
	while((cmp_status & 0x01)== 0);

	return cmp_status;
}

// Change PLL phase
uint8_t AutoUpdatePHCFG(void)
{
	uint32_t PLL_BASE;
	uint32_t Val, Cx, Dir;
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	int pll_ind, spirez;
	uint8_t pllcfgrez;
	tXPLL_CFG pll_cfg = {0};
	int PhaseMin = 0;
	int PhaseMax = 0;
	int PhaseMiddle = 0;
	int PhaseRange = 0;
	int cmp_status = 0;
	int cmp_status_1 = 0;
	int cmp_en = 0;
	int cmp_sel= 0;
	int timeout;
	int lock_status;

	/* State machine for VCTCXO tuning */
	typedef enum state {
	    PHASE_MIN,
	    PHASE_MAX,
	    PHASE_DONE,
	    DO_NOTHING
	} state_t;

	state_t phase_state = PHASE_MIN;

	// Read
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x23;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);

	// Get PLL index
	pll_ind = PLL_IND(rd_buf[3]); //(rd_buf[0] >> 3) & 0x3F;


	// Set Up/Down
	//Dir = PH_DIR(rd_buf[0]); //(rd_buf[1] >> 5) & 0x01;

	// Set Cx
	//Cx = CX_IND(rd_buf[0]) - 2; //(rd_buf[1] & 0x1F);

	// Set Phase Cnt
	//wr_buf[0] = 0x00;	// Command and Address
	//wr_buf[1] = 0x24;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	//Val = CX_PHASE(rd_buf[0], rd_buf[1]); //(rd_buf[1] << 8) | rd_buf[0];

	RdPLLCFG(&pll_cfg);

	switch(pll_ind) {
	case 0:
		cmp_sel = 0x00;
		break;
	case 1:
		cmp_sel = 0x00;
		break;
	case 2:
		cmp_sel = 0x01;
		break;
	case 3:
		cmp_sel = 0x01;
		break;
	default:
		cmp_sel= 0x00;
		break;
	}

	/* Select sample compare MUX */
	XGpio_DiscreteWrite(&smpl_cmp_sel, 1, cmp_sel);
	XGpio_DiscreteWrite(&smpl_cmp_en, 1, 0x00);



	XGpio_DiscreteWrite(&extm_0_axi_sel, 1, pll_ind); 					// Select PLL AXI slave
	pll_cfg.CLKOUT0_PHASE = 0;
	pll_cfg.CLKOUT1_PHASE = 0;

	pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
	pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);

	for (int i=0; i<360; i++){
		//i+=1;

		timeout = 0;
		do
		{
			lock_status = Xil_In32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_STATUS);
		  	if (timeout++ > PLLCFG_TIMEOUT) return PHCFG_ERROR;
		}
		while (!(lock_status & 0x01));

		cmp_status 	= CheckSamples(cmp_sel);

		switch(phase_state) {
		case PHASE_MIN:
			if (cmp_status == 0x01) {
				phase_state = PHASE_MAX;
				PhaseMin = i;
			}
			break;
		case PHASE_MAX:
			if (true)//pll_ind == 1)
			{
			if (cmp_status == 0x03) {
				PhaseMax = i;
				PhaseRange = (PhaseMax - PhaseMin);
				PhaseMiddle = PhaseMin + (PhaseMax - PhaseMin) / 2;
				if (PhaseRange > 5) {
					phase_state = PHASE_DONE;
				}
				else
				{
					phase_state = PHASE_MIN;
				}
			}
			break;
			}
		case PHASE_DONE:
			break;

		default:
			break;

		}

		if (phase_state != PHASE_DONE) {
			XGpio_DiscreteWrite(&smpl_cmp_en, 1, 0x00);
//			 usleep(1000);//asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");
			do {
				cmp_status = XGpio_DiscreteRead(&smpl_cmp_status, 1);
			}
			while((cmp_status & 0x01)!= 0);
			pll_cfg.CLKOUT1_PHASE = i*1000;
			pll_cfg.CLKOUT2_PHASE = i*1000;
			while(!(Xil_In32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_STATUS)));
			pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
			pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);

		}

		else {
			XGpio_DiscreteWrite(&smpl_cmp_en, 1, 0x00);
//			 usleep(1000);//asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");
			do {
				cmp_status = XGpio_DiscreteRead(&smpl_cmp_status, 1);
			}
			while((cmp_status & 0x01)!= 0);
			pll_cfg.CLKOUT1_PHASE = PhaseMiddle*1000;
			pll_cfg.CLKOUT2_PHASE = PhaseMiddle*1000;
			while(!(Xil_In32(XPAR_EXTM_0_AXI_BASEADDR + XIL_CCR_STATUS)));
			pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
			pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);
			return PHCFG_DONE;
			break;
		}

	}



	return PHCFG_ERROR;
}

// Updates PLL configuration
uint8_t UpdatePLLCFG(void)
{
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	int pll_ind, spirez;
	uint8_t pllcfgrez;
	tXPLL_CFG pll_cfg = {0};

	// Get PLL index
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x23;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	pll_ind = PLL_IND(rd_buf[3]); //(rd_buf[0] >> 3) & 0x3F;

	// Select PLL AXI slave to which PLL is connected externally
	XGpio_DiscreteWrite(&extm_0_axi_sel, 1, pll_ind);

	RdPLLCFG(&pll_cfg);

	pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
	pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);

	return pllcfgrez;

}

// Updates PLL configuration
uint8_t UpdateADCPLLCFG(void)
{
	uint8_t wr_buf[4];
	uint8_t rd_buf[4];
	int pll_ind, spirez;
	uint8_t pllcfgrez;
	tXPLL_CFG pll_cfg = {0};

	// Get PLL index
	wr_buf[0] = 0x00;	// Command and Address
	wr_buf[1] = 0x23;	// Command and Address
	//spirez = alt_avalon_spi_command(PLLCFG_SPI_BASE, 0, 2, wr_buf, 2, rd_buf, 0);
	spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
	spirez = XSpi_Transfer(&Spi0, wr_buf, rd_buf, 4);
	pll_ind = 4; //(rd_buf[0] >> 3) & 0x3F;

	// Select PLL AXI slave to which PLL is connected externally
	XGpio_DiscreteWrite(&extm_0_axi_sel, 1, pll_ind);

	RdADCPLLCFG(&pll_cfg);

	pllcfgrez = set_xpll_config(XPAR_EXTM_0_AXI_BASEADDR, &pll_cfg);
	pllcfgrez = start_XReconfig(XPAR_EXTM_0_AXI_BASEADDR);

	return pllcfgrez;

}

void CfgPLL(void)
{
	int pll_stat;

	pll_stat = Xil_In16(XPAR_EXTM_0_AXI_BASEADDR + CLK_CONFIG);

	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + POWER 			, 0xFFFF);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT0_REG1	, 0x1104);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT0_REG2	, 0x0000);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT1_REG1	, 0x1104);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT1_REG2	, 0x0100);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT2_REG1	, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT2_REG2	, 0x00c0);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT3_REG1	, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT3_REG2	, 0x00c0);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT4_REG1	, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT4_REG2	, 0x00c0);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT5_REG1	, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT5_REG2	, 0x00c0);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT6_REG1	, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKOUT6_REG2	, 0x00c0);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + DIVCLK			, 0x1041);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKFBOUT_REG1	, 0x1104);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLKFBOUT_REG2	, 0x0000);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + LOCK_REG1		, 0x01e8);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + LOCK_REG2		, 0x5801);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + LOCK_REG3		, 0x59e9);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + FILTER_REG1	, 0x0800);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + FILTER_REG2	, 0x0900);
	Xil_Out16(XPAR_EXTM_0_AXI_BASEADDR + CLK_CONFIG		, 0x0003);

	//while (Xil_In16(XPAR_EXTM_0_AXI_BASEADDR + CLK_CONFIG) == 3 )

	pll_stat = Xil_In16(XPAR_EXTM_0_AXI_BASEADDR + CLK_CONFIG);

}

///*****************************************************************************/
///**
//*
//* This is the Wait_For_Lock function, it will wait for lock to settle change
//* frequency value
//*
//* @param	CfgPtr_Dynamic provides pointer to clock wizard dynamic config
//*
//* @return
//*		- Error 0 for pass scenario
//*		- Error > 0 for failure scenario
//*
//* @note		None
//*
//******************************************************************************/
//int Wait_For_Lock(XClk_Wiz_Config *CfgPtr_Dynamic)
//{
//	u32 Count = 0;
//	u32 Error = 0;
//
//	while(!(*(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK)) {
//		if(Count == 10000) {
//			Error++;
//			break;
//		}
//		Count++;
//        }
//    return Error;
//}

///*****************************************************************************/
///**
//*
//* This is the Clk_Wiz_Reconfig function, it will reconfigure frequencies as
//* per input array
//*
//* @param	CfgPtr_Dynamic provides pointer to clock wizard dynamic config
//* @param	Findex provides the index for Frequency divide register
//* @param	Sindex provides the index for Frequency phase register
//*
//* @return
//*		-  Error 0 for pass scenario
//*		-  Error > 0 for failure scenario
//*
//* @note	 None
//*
//******************************************************************************/
//int Clk_Wiz_Reconfig(XClk_Wiz_Config *CfgPtr_Dynamic)
//{
//    u32 Count = 0;
//    u32 Error = 0;
//    u32 Fail  = 0;
//    u32 Frac_en = 0;
//    u32 Frac_divide = 0;
//    u32 Divide = 0;
//    float Freq = 0.0;
//
//    Fail = Wait_For_Lock(CfgPtr_Dynamic);
//    if(Fail) {
//	Error++;
//        //xil_printf("\n ERROR: Clock is not locked for default frequency" \
//	" : 0x%x\n\r", *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK);
//     }
//
//    /* SW reset applied */
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x00) = 0xA;
//
//
//    if(*(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK) {
//	Error++;
//       // xil_printf("\n ERROR: Clock is locked : 0x%x \t expected "\
//	  "0x00\n\r", *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK);
//    }
//
//    /* Wait cycles after SW reset */
//    for(Count = 0; Count < 2000; Count++);
//
//    Fail = Wait_For_Lock(CfgPtr_Dynamic);
//    if(Fail) {
//	  Error++;
//          //xil_printf("\n ERROR: Clock is not locked after SW reset :"
//	     // "0x%x \t Expected  : 0x1\n\r",
//	      //*(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK);
//    }
//
//    /* Calculation of Input Freq and Divide factors*/
//    Freq = ((float) CLK_WIZ_VCO_FACTOR/ DYNAMIC_INPUT_FREQ_FACTOR);
//
//    Divide = Freq;
//    Freq = (float)(Freq - Divide);
//
//    Frac_divide = Freq * 10000;
//
//    if(Frac_divide % 10 > 5) {
//	   Frac_divide = Frac_divide + 10;
//    }
//    Frac_divide = Frac_divide/10;
//
//    if(Frac_divide > 1023 ) {
//	   Frac_divide = Frac_divide / 10;
//    }
//
//    if(Frac_divide) {
//	   /* if fraction part exists, Frac_en is shifted to 26
//	    * for input Freq */
//	   Frac_en = (CLK_FRAC_EN << 26);
//    }
//    else {
//	   Frac_en = 0;
//    }
//
//    /* Configuring Multiply and Divide values */
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x200) = \
//	Frac_en | (Frac_divide << 16) | (Divide << 8) | 0x01;
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x204) = 0x00;
//
//    /* Calculation of Output Freq and Divide factors*/
//    Freq = ((float) CLK_WIZ_VCO_FACTOR / DYNAMIC_OUTPUT_FREQFACTOR);
//
//    Divide = Freq;
//    Freq = (float)(Freq - Divide);
//
//    Frac_divide = Freq * 10000;
//
//    if(Frac_divide%10 > 5) {
//	Frac_divide = Frac_divide + 10;
//    }
//    Frac_divide = Frac_divide / 10;
//
//    if(Frac_divide > 1023 ) {
//        Frac_divide = Frac_divide / 10;
//    }
//
//    if(Frac_divide) {
//	/* if fraction part exists, Frac_en is shifted to 18 for output Freq */
//	Frac_en = (CLK_FRAC_EN << 18);
//    }
//    else {
//	Frac_en = 0;
//    }
//
//    /* Configuring Multiply and Divide values */
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x208) =
//	    Frac_en | (Frac_divide << 8) | (Divide);
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x20C) = 0x00;
//
//    /* Load Clock Configuration Register values */
//    *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x25C) = 0x07;
//
//    if(*(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK) {
//	Error++;
//       // xil_printf("\n ERROR: Clock is locked : 0x%x \t expected "
//	   // "0x00\n\r", *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK);
//     }
//
//     /* Clock Configuration Registers are used for dynamic reconfiguration */
//     *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x25C) = 0x02;
//
//    Fail = Wait_For_Lock(CfgPtr_Dynamic);
//    if(Fail) {
//	Error++;
//        //xil_printf("\n ERROR: Clock is not locked : 0x%x \t Expected "\
//	": 0x1\n\r", *(u32 *)(CfgPtr_Dynamic->BaseAddr + 0x04) & CLK_LOCK);
//    }
//	return Error;
//}


int main()
{
	int PAGE_SIZE = 256; // page size
	u8 page_buffer[256]; // page buffer
	u16 page_buffer_cnt; // how many bytes are present in buffer
	u8 inc_data_count;   // how much data we got
	u8 data_to_copy;     // how much data to copy to page buffer (incase of overflow)
	u8 data_leftover;
	u64 total_data=0;    // how much data has been transferred in total (debug value)
	int address;

	uint8_t wr_buf[4];
	uint8_t rd_buf[4];

	uint8_t phcfg_start_old, phcfg_start;
	uint8_t pllcfg_start_old, pllcfg_start;
	uint8_t pllrst_start_old, pllrst_start;
	uint8_t phcfg_mode;
tXPLL_CFG pll_cfg = {0};
	uint8_t pllcfgrez;
	uint16_t phcfgrez;

	u32 pll_stat;

	u32 Fail  = 0;

//	XClk_Wiz_Config *CfgPtr_Mon;
//	XClk_Wiz_Config *CfgPtr_Dynamic;
	u32 Status = XST_SUCCESS;

	int spirez;
	uint32_t* dest = (uint32_t*)glEp0Buffer_Tx;
	u8 spi_WriteBuffer[4];
	u8 spi_ReadBuffer[4];
	int spi_ByteCount;
	u8 Iic_WriteBuffer[2];
	u8 Iic_ReadBuffer[2];
	int ByteCount;
	

    init_platform();

    //initialize XGpio variable
    XGpio_Initialize(&gpio, XPAR_ADC_RESET_GPIO_DEVICE_ID);
    XGpio_Initialize(&pll_rst, XPAR_PLL_GPIO_PLL_RST_DEVICE_ID);
    XGpio_Initialize(&pllcfg_cmd, XPAR_PLL_GPIO_PLLCFG_COMMAND_DEVICE_ID);
    XGpio_Initialize(&pllcfg_stat, XPAR_PLL_GPIO_PLLCFG_STATUS_DEVICE_ID);
    XGpio_Initialize(&extm_0_axi_sel, XPAR_PLL_GPIO_PLL_SEL_DEVICE_ID);
    XGpio_Initialize(&smpl_cmp_sel, XPAR_SMPL_CMP_GPIO_SMPL_CMP_SEL_DEVICE_ID);
    XGpio_Initialize(&smpl_cmp_en, XPAR_SMPL_CMP_GPIO_SMPL_CMP_CMD_DEVICE_ID);
    XGpio_Initialize(&smpl_cmp_status, XPAR_SMPL_CMP_GPIO_SMPL_CMP_STAT_DEVICE_ID);
    XGpio_Initialize(&vctcxo_tamer_ctrl, XPAR_VCTCXO_TAMER_CTRL_DEVICE_ID);



	// Initialize variables to detect PLL phase change and PLL config update request
	phcfg_start_old = 0; phcfg_start = 0;
	pllcfg_start_old = 0; pllcfg_start = 0;
	pllrst_start_old = 0; pllrst_start = 0;

    Init_SPI(SPI0_DEVICE_ID, &Spi0, XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION);
    Init_flash_qspi(QSPI_DEVICE_ID, &CFG_QSPI, XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION);
    // Default config

	//pllcfgrez = AutoUpdatePHCFG();

	RdPLLCFG(&pll_cfg);
	//pllcfgrez = UpdatePLLCFG();


    while (1)
    {
		
	    // Check if there is a request for PLL phase update
 	    if((phcfg_start_old == 0) && (phcfg_start != 0))
	    {
	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, PLLCFG_BUSY);
	    	//XGpio_DiscreteWrite(&pllcfg_stat, 1, PLLCFG_BUSY);
	    	//phcfg_mode = (IORD(PLLCFG_COMMAND_BASE, 0x00) & 0x08) >> 3;
	    	phcfg_mode = (XGpio_DiscreteRead(&pllcfg_cmd, 1) & 0x08) >> 3;
	    	if (phcfg_mode){
	    			phcfgrez = AutoUpdatePHCFG();


	    	}
	    	else{
	    			phcfgrez = 0x01;

	    	};

	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, (pllcfgrez << 2) | PLLCFG_DONE);
	    	//pllcfgrez = 0x00;
	    	//XGpio_DiscreteWrite(&pllcfg_stat, 1 , (pllcfgrez << 2) | PLLCFG_DONE);
	    	//XGpio_DiscreteWrite(&pllcfg_stat, 1 , PLLCFG_DONE | PHCFG_DONE);
	    	XGpio_DiscreteWrite(&pllcfg_stat, 1 , (phcfgrez << 10) | PLLCFG_DONE);
	    }

	    // Check if there is a request for PLL configuration update
	    if((pllcfg_start_old == 0) && (pllcfg_start != 0))
	    {
	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, PLLCFG_BUSY);
	    	XGpio_DiscreteWrite(&pllcfg_stat, 1, PLLCFG_BUSY);
	    	pllcfgrez = UpdatePLLCFG();
	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, (pllcfgrez << 2) | PLLCFG_DONE);
	    	pllcfgrez = 0x00;
	    	//XGpio_DiscreteWrite(&pllcfg_stat, 1 , (pllcfgrez << 2) | PLLCFG_DONE);
	    	XGpio_DiscreteWrite(&pllcfg_stat, 1 , PLLCFG_DONE);
	    }

	    // Check if there is a request for PLL configuration update
	    if((pllrst_start_old == 0) && (pllrst_start != 0))
	    {
	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, PLLCFG_BUSY);
	    	//XGpio_DiscreteWrite(&pllcfg_stat, 1, PLLCFG_BUSY);
	    	ResetPLL();
	    	//IOWR(PLLCFG_STATUS_BASE, 0x00, PLLCFG_DONE);
	    	XGpio_DiscreteWrite(&pllcfg_stat, 1,  PLLCFG_DONE);
	    }

	    // Update PLL configuration command status
	    pllrst_start_old = pllrst_start;
	    //pllrst_start = (IORD(PLLCFG_COMMAND_BASE, 0x00) & 0x04) >> 2;
	    pllrst_start = (XGpio_DiscreteRead(&pllcfg_cmd, 1) & 0x04) >> 2;
	    phcfg_start_old = phcfg_start;
	    //phcfg_start = (IORD(PLLCFG_COMMAND_BASE, 0x00) & 0x02) >> 1;
	    phcfg_start = (XGpio_DiscreteRead(&pllcfg_cmd, 1) & 0x02) >> 1;
	    pllcfg_start_old = pllcfg_start;
	    //pllcfg_start = IORD(PLLCFG_COMMAND_BASE, 0x00) & 0x01;
	    pllcfg_start = XGpio_DiscreteRead(&pllcfg_cmd, 1) & 0x01;

    	// Read FIFO Status
    	spirez = AXI_TO_NATIVE_FIFO_mReadReg(XPAR_AXI_TO_NATIVE_FIFO_0_S00_AXI_BASEADDR, AXI_TO_NATIVE_FIFO_S00_AXI_SLV_REG2_OFFSET);

        if(!(spirez & 0x01))
        {
        	//Toggle FIFO reset
        	AXI_TO_NATIVE_FIFO_mWriteReg(XPAR_AXI_TO_NATIVE_FIFO_0_S00_AXI_BASEADDR, AXI_TO_NATIVE_FIFO_S00_AXI_SLV_REG3_OFFSET, 0x01);
        	AXI_TO_NATIVE_FIFO_mWriteReg(XPAR_AXI_TO_NATIVE_FIFO_0_S00_AXI_BASEADDR, AXI_TO_NATIVE_FIFO_S00_AXI_SLV_REG3_OFFSET, 0x00);

        	getFifoData(glEp0Buffer_Rx, 64);

         	memset (glEp0Buffer_Tx, 0, sizeof(glEp0Buffer_Tx)); //fill whole tx buffer with zeros
         	cmd_errors = 0;

     		LMS_Ctrl_Packet_Tx->Header.Command = LMS_Ctrl_Packet_Rx->Header.Command;
     		LMS_Ctrl_Packet_Tx->Header.Data_blocks = LMS_Ctrl_Packet_Rx->Header.Data_blocks;
     		LMS_Ctrl_Packet_Tx->Header.Periph_ID = LMS_Ctrl_Packet_Rx->Header.Periph_ID;
     		LMS_Ctrl_Packet_Tx->Header.Status = STATUS_BUSY_CMD;

     		switch(LMS_Ctrl_Packet_Rx->Header.Command)
     		{
 				case CMD_GET_INFO:

 					LMS_Ctrl_Packet_Tx->Data_field[0] = FW_VER;
 					LMS_Ctrl_Packet_Tx->Data_field[1] = DEV_TYPE;
 					LMS_Ctrl_Packet_Tx->Data_field[2] = LMS_PROTOCOL_VER;
 					LMS_Ctrl_Packet_Tx->Data_field[3] = HW_VER;
 					LMS_Ctrl_Packet_Tx->Data_field[4] = EXP_BOARD;

 					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 				break;

// COMMAND LMS RESET

 				case CMD_LMS_RST:

					if (!Check_Periph_ID(MAX_ID_LMS7, LMS_Ctrl_Packet_Rx->Header.Periph_ID))
						break;

					// Store memory map address in buffer
					temp_buffer0[0] = MEMORY_MAP_REG_MSB;
					temp_buffer0[1] = MEMORY_MAP_REG_LSB;
					// Read current memory map value (for restoring it later)
					// The current value is stored in temp_buffer1[3-4]
					Board_SPI_Read(temp_buffer0, temp_buffer1, &Spi0, SPI0_FPGA_SS);

	 				switch(LMS_Ctrl_Packet_Rx->Header.Periph_ID)
	 				{
						 // Set memory map value
						 // temp_buffer0 still contains the memory map address
	 					case 0:
							temp_buffer0[3] = 1;
							break;
	 					case 1:
						 	temp_buffer0[3] = 2;
	 						break;
	 					case 2:
						 	temp_buffer0[3] = 4;
		 					break;
	 					default:
	 						cmd_errors++;
	 					break;
	 				}
					 //Write new memory map value
					Board_SPI_Write(temp_buffer0,&Spi0, SPI0_FPGA_SS);
					//Do the reset
					switch (LMS_Ctrl_Packet_Rx->Data_field[0])
					{
 						case LMS_RST_DEACTIVATE:
 		 						Modify_BRDSPI16_Reg_bits (BRD_SPI_REG_LMS1_LMS2_CTRL, LMS1_RESET, LMS1_RESET, 1); //high level
 		 						break;
 						case LMS_RST_ACTIVATE:
 		 						Modify_BRDSPI16_Reg_bits (BRD_SPI_REG_LMS1_LMS2_CTRL, LMS1_RESET, LMS1_RESET, 0); //low level
 		 						break;

 						case LMS_RST_PULSE:
 		 						Modify_BRDSPI16_Reg_bits (BRD_SPI_REG_LMS1_LMS2_CTRL, LMS1_RESET, LMS1_RESET, 0); //low level
 		 						Modify_BRDSPI16_Reg_bits (BRD_SPI_REG_LMS1_LMS2_CTRL, LMS1_RESET, LMS1_RESET, 1); //high level
 		 						break;
 						default:
 							cmd_errors++;
 						break;
 					}
					 // Restore old memory map value
					temp_buffer0[2] = temp_buffer1[2];
					temp_buffer0[3] = temp_buffer1[3];

					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 				break;

// COMMAND LMS WRITE

 				case CMD_LMS7002_WR:
 					if(!Check_Periph_ID(MAX_ID_LMS7, LMS_Ctrl_Packet_Rx->Header.Periph_ID)) break;
 					if(Check_many_blocks (4)) break;

 					for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
 					{
 						//Write LMS7 register
 						sbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 7); //set write bit
 					    spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_LMS7002M_1_SS);
 						//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, LMS_Ctrl_Packet_Rx->Header.Periph_ID == 1 ? SPI_NR_LMS7002M_1 : SPI_NR_LMS7002M_0,
 								//4, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 0, NULL, 0);

 						spirez = XSpi_Transfer(&Spi0, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], NULL, 4);
 					}

 					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 				break;

// COMMAND LMS READ

 				case CMD_LMS7002_RD:
 					if(Check_many_blocks (4)) break;

 					for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
 					{
 						//Read LMS7 register
 						cbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 7);  //clear write bit
 						spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_LMS7002M_1_SS);
 						//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, LMS_Ctrl_Packet_Rx->Header.Periph_ID == 1 ? SPI_NR_LMS7002M_1 : SPI_NR_LMS7002M_0,
 								//2, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 2, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)], 0);

 						spirez = XSpi_Transfer(&Spi0, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], spi_ReadBuffer, 4);
 						LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)] = spi_ReadBuffer[2];
 						LMS_Ctrl_Packet_Tx->Data_field[3 + (block * 4)] = spi_ReadBuffer[3];

 					}

 					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 				break;

// COMMAND BOARD SPI WRITE

 	 			case CMD_BRDSPI16_WR:
 	 				if(Check_many_blocks (4)) break;

 	 				for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
 	 				{
 	 					//write reg addr
 	 					sbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 7); //set write bit

 	 					//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, SPI_NR_FPGA, 4, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 0, NULL, 0);
 	 					spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);
 	 					spirez = XSpi_Transfer(&Spi0, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], NULL, 4);
 	 				}

 	 				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 	 			break;

// COMMAND BOARD SPI READ

 				case CMD_BRDSPI16_RD:
 					if(Check_many_blocks (4)) break;

 					for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
 					{

 						//write reg addr
 						cbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 7);  //clear write bit

 						//spirez = alt_avalon_spi_command(FPGA_SPI0_BASE, SPI_NR_FPGA, 2, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 2, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)], 0);
 						spirez = XSpi_SetSlaveSelect(&Spi0, SPI0_FPGA_SS);

 						spirez = XSpi_Transfer(&Spi0, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], spi_ReadBuffer, 4);
 						LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)] = spi_ReadBuffer[2];
 						LMS_Ctrl_Packet_Tx->Data_field[3 + (block * 4)] = spi_ReadBuffer[3];

 					}

 					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
 				break;


case CMD_ALTERA_FPGA_GW_WR: //FPGA active serial


						current_portion = (LMS_Ctrl_Packet_Rx->Data_field[1] << 24) | (LMS_Ctrl_Packet_Rx->Data_field[2] << 16) | (LMS_Ctrl_Packet_Rx->Data_field[3] << 8) | (LMS_Ctrl_Packet_Rx->Data_field[4]);
						data_cnt = LMS_Ctrl_Packet_Rx->Data_field[5];

						switch(LMS_Ctrl_Packet_Rx->Data_field[0])//prog_mode
						{
							/*
							Programming mode:
							0 - Bitstream to FPGA
							1 - Bitstream to Flash
							2 - Bitstream from FLASH
							*/
							// TODO: Add return value checks

							case 1: //write data to Flash from PC
								//Reset spirez
								spirez = 0;
								//Start of programming? reset variables
								if (current_portion == 0)
									{
										address = 0;
										page_buffer_cnt = 0;
										total_data      = 0;
										//Erase firt sector
										spirez = spirez || FlashQspi_EraseSector(&CFG_QSPI,0);
									}

								inc_data_count = LMS_Ctrl_Packet_Rx->Data_field[5];

								// Check if final packet
								if (inc_data_count == 0)
								{	//Flush letftover data, if any
									if (page_buffer_cnt > 0)
									{
										//Fill unused page data with 1 (no write)
										memset(&page_buffer[page_buffer_cnt],0xFF,PAGE_SIZE-page_buffer_cnt);
										spirez = spirez ||FlashQspi_ProgramPage(&CFG_QSPI,address,page_buffer);
									}
								}
								else
								{
									if (PAGE_SIZE < (inc_data_count + page_buffer_cnt))
									{	// Incoming data would overflow the page buffer
										// Calculate ammount of data to copy
										data_to_copy = PAGE_SIZE - page_buffer_cnt;
										data_leftover = page_buffer_cnt - data_to_copy;
										memcpy(&page_buffer[page_buffer_cnt], &LMS_Ctrl_Packet_Rx->Data_field[24], data_to_copy);
										// We already know the page is full because of overflowing input
										spirez = spirez ||FlashQspi_ProgramPage(&CFG_QSPI,address,page_buffer);
										address += 256;
										total_data += 256;
										//Check if new address is bottom of sector, erase if needed
										if ((address & 0xFFF) == 0)
											spirez = spirez ||FlashQspi_EraseSector(&CFG_QSPI,address);
										memcpy(&page_buffer[0], &LMS_Ctrl_Packet_Rx->Data_field[24+data_to_copy], data_leftover);
										page_buffer_cnt = data_leftover;
									}
									else
									{   // Incoming data would not overflow the page buffer
										memcpy(&page_buffer[page_buffer_cnt], &LMS_Ctrl_Packet_Rx->Data_field[24], inc_data_count);
										page_buffer_cnt += inc_data_count;
										if(page_buffer_cnt == PAGE_SIZE)
										{
											spirez = spirez ||FlashQspi_ProgramPage(&CFG_QSPI,address,page_buffer);
											page_buffer_cnt = 0;
											address += 256;
											total_data += 256;
											//Check if new address is bottom of sector, erase if needed
											if ((address & 0xFFF) == 0)
												spirez = spirez ||FlashQspi_EraseSector(&CFG_QSPI,address);
										}
									}
								}
							if (spirez == XST_SUCCESS)
							{
								LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
							}
							else
							{
								LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
							}
							break;

							default:
								LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
								break;
						}

						break;				

// COMMAND ANALOG VALUE READ

				case CMD_ANALOG_VAL_RD:

					for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
					{
						switch (LMS_Ctrl_Packet_Rx->Data_field[0 + (block)])//ch
						{
							default:
								cmd_errors++;
							break;
						}
					}

					if(cmd_errors)
						LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
					else
						LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;

				break;

// COMMAND ANALOG VALUE WRITE

				case CMD_ANALOG_VAL_WR:
					if(Check_many_blocks (4)) break;

					for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
					{
						switch (LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)]) //do something according to channel
						{
//							case 0: //TCXO DAC
//								if (LMS_Ctrl_Packet_Rx->Data_field[1 + (block * 4)] == 0) //RAW units?
//								{
//									Control_TCXO_ADF(0, NULL); //set ADF4002 CP to three-state
//
//									//write data to DAC
//									//dac_val = LMS_Ctrl_Packet_Rx->Data_field[3 + (block * 4)];
//									dac_val = (LMS_Ctrl_Packet_Rx->Data_field[2 + (block * 4)] << 8 ) + LMS_Ctrl_Packet_Rx->Data_field[3 + (block * 4)];
//									Control_TCXO_DAC(1, &dac_val); //enable DAC output, set new val
//								}
//								else cmd_errors++;
//							break;
//							case 2: //TCXO DAC
//								if (LMS_Ctrl_Packet_Rx->Data_field[1 + (block * 4)] == 0) //RAW units?
//								{
//									pa1_dac_val = (LMS_Ctrl_Packet_Rx->Data_field[2 + (block * 4)] << 8 ) + LMS_Ctrl_Packet_Rx->Data_field[3 + (block * 4)];
//									Control_SPI2_DAC(1, &pa1_dac_val, SPI2_PA1_SS); //enable DAC output, set new val
//								}
//								else cmd_errors++;
//							break;
//							case 3: //TCXO DAC
//								if (LMS_Ctrl_Packet_Rx->Data_field[1 + (block * 4)] == 0) //RAW units?
//								{
//									pa2_dac_val = (LMS_Ctrl_Packet_Rx->Data_field[2 + (block * 4)] << 8 ) + LMS_Ctrl_Packet_Rx->Data_field[3 + (block * 4)];
//									Control_SPI2_DAC(1, &pa2_dac_val, SPI2_PA2_SS); //enable DAC output, set new val
//								}
//								else cmd_errors++;
//							break;

							default:
								cmd_errors++;
							break;
						}
					}

					if(cmd_errors)
						LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
					else
						LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;

					break;

				case CMD_MEMORY_WR:

//									current_portion = (LMS_Ctrl_Packet_Rx->Data_field[1] << 24) | (LMS_Ctrl_Packet_Rx->Data_field[2] << 16) | (LMS_Ctrl_Packet_Rx->Data_field[3] << 8) | (LMS_Ctrl_Packet_Rx->Data_field[4]);
//									data_cnt = LMS_Ctrl_Packet_Rx->Data_field[5];
//
//									if((LMS_Ctrl_Packet_Rx->Data_field[10] == 0) && (LMS_Ctrl_Packet_Rx->Data_field[11] == 3)) //TARGET = 3 (EEPROM)
//									{
//										if(LMS_Ctrl_Packet_Rx->Data_field[0] == 0) //write data to EEPROM #1
//										{
//											LMS_Ctrl_Packet_Rx->Data_field[22] = LMS_Ctrl_Packet_Rx->Data_field[8];
//											LMS_Ctrl_Packet_Rx->Data_field[23] = LMS_Ctrl_Packet_Rx->Data_field[9];
//
//											XIic_Send(XPAR_AXI_IIC_0_BASEADDR, I2C_ADDR_EEPROM, (u8 *)&LMS_Ctrl_Packet_Rx->Data_field[22], ByteCount+2, XIIC_STOP);
//											usleep(5000);
//
//											if(cmd_errors) LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//											else LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
//
//										}
//										else
//											LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//									}
//									else
//										LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//								break;
//
//
//								case CMD_MEMORY_RD:
////									current_portion = (LMS_Ctrl_Packet_Rx->Data_field[1] << 24) | (LMS_Ctrl_Packet_Rx->Data_field[2] << 16) | (LMS_Ctrl_Packet_Rx->Data_field[3] << 8) | (LMS_Ctrl_Packet_Rx->Data_field[4]);
//									data_cnt = LMS_Ctrl_Packet_Rx->Data_field[5];
//
//									if((LMS_Ctrl_Packet_Rx->Data_field[10] == 0) && (LMS_Ctrl_Packet_Rx->Data_field[11] == 3)) ///TARGET = 3 (EEPROM)
//									{
//										if(LMS_Ctrl_Packet_Rx->Data_field[0] == 0) //read data from EEPROM #1
//										{
//
//											XIic_Send(XPAR_AXI_IIC_0_BASEADDR, I2C_ADDR_EEPROM, (u8 *)&LMS_Ctrl_Packet_Rx->Data_field[8], 2, XIIC_STOP);
//											XIic_Recv(XPAR_AXI_IIC_0_BASEADDR, I2C_ADDR_EEPROM, (u8 *)&glEp0Buffer_Tx[32], ByteCount, XIIC_STOP);
//
//											if(cmd_errors) LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//											else LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
//										}
//										else
//											LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//									}
//									else
//										LMS_Ctrl_Packet_Tx->Header.Status = STATUS_ERROR_CMD;
//
//								break;
//
//
//				break;

 				default:
 					/* This is unknown request. */
 					//isHandled = CyFalse;
 					LMS_Ctrl_Packet_Tx->Header.Status = STATUS_UNKNOWN_CMD;
 				break;
     		};

     		//Send response to the command
        	for(int i=0; i<64/sizeof(uint32_t); ++i)
        	{
        		AXI_TO_NATIVE_FIFO_mWriteReg(XPAR_AXI_TO_NATIVE_FIFO_0_S00_AXI_BASEADDR, AXI_TO_NATIVE_FIFO_S00_AXI_SLV_REG0_OFFSET, dest[i]);
			}


        }

    }





    //print("Hello World\n\r");

    cleanup_platform();
    return 0;
}
